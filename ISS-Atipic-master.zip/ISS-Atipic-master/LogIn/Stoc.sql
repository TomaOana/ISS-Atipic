﻿CREATE TABLE [dbo].[Stoc]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [Grupa] VARCHAR(50) NULL, 
    [Trombocite] INT NULL, 
    [Globule rosii] INT NULL, 
    [Plasma] INT NULL, 
    [Sange total] INT NULL
)
